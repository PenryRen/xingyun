import{a as i}from"./index.25cd3d66.js";function r(t){return i("/api/train/item/user/question/list",t)}export{r as u};
