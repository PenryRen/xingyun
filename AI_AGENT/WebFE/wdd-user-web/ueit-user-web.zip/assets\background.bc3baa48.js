const s="/assets/logo-white.120a5148.png",o="/assets/background.266e805b.png";export{s as _,o as a};
