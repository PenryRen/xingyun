import{O as a}from"./index.de474af9.js";function t(e){return a("/api/user/log/event/page",e)}function n(e){return a("/api/user/log/feedback/page",e)}export{t as e,n as f};
