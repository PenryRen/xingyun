import{O as a}from"./index.8430702d.js";function t(e){return a("/api/user/log/event/page",e)}function n(e){return a("/api/user/log/feedback/page",e)}export{t as e,n as f};
