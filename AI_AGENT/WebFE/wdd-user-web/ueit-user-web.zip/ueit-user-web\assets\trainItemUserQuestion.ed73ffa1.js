import{p as i}from"./index.6ebeda64.js";function r(t){return i("/api/train/item/user/question/list",t)}export{r as u};
